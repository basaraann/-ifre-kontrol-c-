﻿/****************************************************************************
**					SAKARYA ÜNİVERSİTESİ
**				BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				    BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   NESNEYE DAYALI PROGRAMLAMA DERSİ
**					2014-2015 BAHAR DÖNEMİ
**	
**				ÖDEV NUMARASI..........:1.ödev
**				ÖĞRENCİ ADI............:Buğra Başaran
**				ÖĞRENCİ NUMARASI.......:G211210015
**                         DERSİN ALINDIĞI GRUP...:2.öğretim B grubu
****************************************************************************/

using System;

namespace Guvenlik
{
    public static class Sifre
    {
        public static int ToplamOzelKarakterSayisi;
        public static int ToplamBuyukHarfSayisi;
        public static int ToplamKucukHarfSayisi;
        public static int ToplamRakamSayisi;
        public static char[] karakterler;
        public static void sayiUyumluluk()
        {
            foreach (char karakter in karakterler)
            {
                if (char.IsDigit(karakter))
                {
                    Sifre.ToplamRakamSayisi++;
                }
            }
        }
        public static void BuyukHarfUyumu()
        {
            foreach (char karakter in karakterler)
            {
                if (char.IsUpper(karakter))
                {
                    Sifre.ToplamBuyukHarfSayisi++;
                }
            }
        }
        public static void KucukHarfUyumu()
        {
            foreach (char karakter in karakterler)
            {
                if (char.IsLower(karakter))
                {
                    Sifre.ToplamKucukHarfSayisi++;
                }
            }
        }
        public static void SembolUyumu()
        {
            foreach (char karakter in karakterler)
            {
                if (char.IsSymbol(karakter) || char.IsPunctuation(karakter))
                {
                    Sifre.ToplamOzelKarakterSayisi++;
                }
            }
        }
    }
        class Program
        {
            static void Main()
            {
                int Kontrol = 0;
                while (Kontrol == 0)
                {
                     Sifre.ToplamBuyukHarfSayisi = 0;
                     Sifre.ToplamRakamSayisi = 0;
                     Sifre.ToplamOzelKarakterSayisi = 0;
                     Sifre.ToplamKucukHarfSayisi = 0;
                     int puan = 0;
                    
                    Console.WriteLine("sifrenizi giriniz");
                    baslama();
                    int baslama()
                    {
                        string sifre = Console.ReadLine();
                        Sifre.karakterler = sifre.ToArray();
                        uzunlukKontrol();
                        return puan;
                    }
                    void uzunlukKontrol()
                    {
                        if (Sifre.karakterler.Length >= 9)
                        {
                            puan = puan + 10;
                       
                        } 
                        else
                        {
                            Console.WriteLine("sifre uzunlugu yetersiz...");
                        }
                       
                    }
                             Sifre.sayiUyumluluk();
                             Sifre.BuyukHarfUyumu();
                             Sifre.KucukHarfUyumu();
                             Sifre.SembolUyumu();


                if (Sifre.ToplamBuyukHarfSayisi > 0 && Sifre.ToplamKucukHarfSayisi > 0 && Sifre.ToplamOzelKarakterSayisi > 0 && Sifre.ToplamRakamSayisi > 0)
                {
                    if (Sifre.karakterler.Length - Sifre.ToplamBuyukHarfSayisi - Sifre.ToplamKucukHarfSayisi - Sifre.ToplamOzelKarakterSayisi - Sifre.ToplamRakamSayisi == 0)
                    {
                        if (Sifre.ToplamRakamSayisi > 1)
                        {
                            puan = puan + 20;
                        }
                        else if (Sifre.ToplamRakamSayisi == 1)
                        {
                            puan = puan + 10;
                        }
                        if (Sifre.ToplamKucukHarfSayisi > 1)
                        {
                            puan = puan + 20;
                        }
                        else if (Sifre.ToplamKucukHarfSayisi == 1)
                        {
                            puan = puan + 10;
                        }
                        if (Sifre.ToplamBuyukHarfSayisi == 1)
                        {
                            puan = puan + 10;
                        }
                        else if (Sifre.ToplamBuyukHarfSayisi > 1)
                        {
                            puan = puan + 20;
                        }
                        if (Sifre.ToplamOzelKarakterSayisi >= 1)
                        {
                            if (Sifre.ToplamOzelKarakterSayisi > 3)
                            {
                                puan += 30;
                            }
                            else
                            {
                                puan = puan + (Sifre.ToplamOzelKarakterSayisi * 10);
                            }
                        }
                        if (puan < 70)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("sifre geçersiz");
                            Console.ForegroundColor = ConsoleColor.White;
                            Kontrol = 0; 
                        }
                        if (Sifre.karakterler.Length >= 9)
                        {
                            if (puan >= 70 && puan < 90)
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("sifre kabul edilir");
                                Console.ForegroundColor = ConsoleColor.White;
                                Kontrol = 1;
                            }
                            
                        }
                        if (puan >= 90 && puan <= 100)
                        {
                           Kontrol = 1;
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("sifre çok güçlü");
                            Console.ForegroundColor = ConsoleColor.White;
                        }

                        if (puan <= 100)
                        {
                            Console.WriteLine("puanınız = " + puan);
                        }
                        Console.WriteLine("Buyuk Harf Sayisi = " + Sifre.ToplamBuyukHarfSayisi);
                        Console.WriteLine("Kucuk Harf Sayisi = " + Sifre.ToplamKucukHarfSayisi);
                        Console.WriteLine("Rakam Sayisi = " + Sifre.ToplamRakamSayisi);
                        Console.WriteLine("Ozel karakter(sembol) Sayisi = " + Sifre.ToplamOzelKarakterSayisi);
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Sifrenizde bosluk karakteri bulunamaz tekrar deneyiniz...");
                        Console.ForegroundColor = ConsoleColor.White;
                        Kontrol = 0;
                    }
                  }
                  else
                  {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Şifrenizde en az bir kucuk harf,buyuk harf,rakam ve özel karakter bulunmalıdır.Tekrar deneyiniz.");
                    Console.ForegroundColor = ConsoleColor.White;
                  }
                }
            }
        }
}
